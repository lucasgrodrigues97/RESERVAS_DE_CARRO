package dados;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Scanner;



public class Usuario {

	public static void main(String[] args) {
		Scanner leia = new Scanner(System.in);
		System.out.println("***RESERVA DE CARROS***");
		int tipoCliente;
		int tipoCarro;
		String cliente;
		int quantPassageiro = 0;
		String data = null;
		double preco = 0;

		do {
			System.out.println("( 1-Cliente Regular / 2-Cliente Fidelidade ) :");
			tipoCliente = leia.nextInt();
			if (tipoCliente < 1 || tipoCliente > 2) {
				System.out.println("Opcao inv�lida");
			}
		} while (tipoCliente < 1 || tipoCliente > 2);

		if (tipoCliente == 1) {
			cliente = "Normal";
		} else {
			cliente = "Premium";
		}

		do {
			System.out.println("Digite o tipo do carro que deseja (1-Compacto/2-Esportivo/3-SUV's): ");
			tipoCarro = leia.nextInt();
			if (tipoCarro < 1 || tipoCarro > 3) {
				System.out.println("Opcao inv�lida.");
			}
		} while(tipoCarro < 1 || tipoCarro > 3);

		if (tipoCarro == 1) {
			do {
				System.out.println("Digite a quantidade de passageiros: ");
				quantPassageiro = leia.nextInt();
				if (quantPassageiro < 1 || quantPassageiro > 4) {
					System.out.println("Opcao inv�lida. Digite entre 1 e 4");
				}
			} while(quantPassageiro < 1 || quantPassageiro > 4);
		} else if (tipoCarro == 2) {
			do {
				System.out.println("Digite a quantidade de passageiros: ");
				quantPassageiro = leia.nextInt();
				if (quantPassageiro < 1 || quantPassageiro > 2) {
					System.out.println("Opcao inv�lida. Digite 1 ou 2");
				}
			} while(quantPassageiro < 1 || quantPassageiro > 2);
		} else if (tipoCarro == 3) {
			do {
				System.out.println("Digite a quantidade de passageiros: ");
				quantPassageiro = leia.nextInt();
				if (quantPassageiro < 1 || quantPassageiro > 7) {
					System.out.println("Opcao inv�lida. Digite entre 1 e 7");
				}
			} while(quantPassageiro < 1 || quantPassageiro > 7);
		}

		GregorianCalendar dataEx = new GregorianCalendar();
		int quantDatas;
		do {
			System.out.println("Digite quantos dias voce deseja: ");
			quantDatas = leia.nextInt();
			if (quantDatas < 0) {
				System.out.println("Opcao invalida.");
			}
		} while (quantDatas < 0);
		leia.nextLine();

		for (int i = 1; i <= quantDatas; i++) {
			while (true) {
				System.out.println("Digite a " + i  + "� data (Formato DD/MM/AAAA) : ");
				data = leia.nextLine();
				if ( ! Validacoes.validaData(data)) {
					System.out.println("Formato invalido.");
					continue;
				} else break;
			}
		}

		//segunda a sexta
		if (tipoCliente == 1) {
			if (tipoCarro == 1) {
				preco = 210;
			} else if (tipoCarro == 2) {
				preco = 530;
			} else {
				preco = 630;
			}
		} else if (tipoCliente == 2) {
			if (tipoCarro == 1) {
				preco = 150;
			} else if (tipoCarro == 2) {
				preco = 150;
			} else {
				preco = 580;
			}
		}

		switch (dataEx.get(GregorianCalendar.DAY_OF_WEEK)) {
		case 7://sabado
			if (tipoCliente == 1) {
				if (tipoCarro == 1) {
					preco = 200;
				} else if (tipoCarro == 2) {
					preco = 200;
				} else {
					preco = 600;
				}
			} else if (tipoCliente == 2) {
				if (tipoCarro == 1) {
					preco = 90;
				} else if (tipoCarro == 2) {
					preco = 90;
				} else {
					preco = 590;
				}
			}
			break;
		case 1://domingo
			if (tipoCliente == 1) {
				if (tipoCarro == 1) {
					preco = 200;
				} else if (tipoCarro == 2) {
					preco = 200;
				} else {
					preco = 600;
				}
			} else if (tipoCliente == 2) {
				if (tipoCarro == 1) {
					preco = 90;
				} else if (tipoCarro == 2) {
					preco = 90;
				} else {
					preco = 590;
				}
			}
			break;
		}

		//input
		//System.out.println(cliente + ": " + quantPassageiro + ": " + data...);

		//output
		if(tipoCarro == 1) {
			System.out.println("Nissan March, Volkswagen Polo, Ford New Fiesta, Hyundai HB20, Honda FIT : SouthCar  - Pre�o: R$" + preco);
		} else if (tipoCarro == 2) {
			System.out.println("Ferrari, Peugeot EX1, Lamborghini : WestCar  - Pre�o: R$" + preco);
		} else {
			System.out.println("Navigator, Ford EcoSport, Renault Duster, Hyunday Tucson, Mitsubishi ASX : NorthCar  - Pre�o: R$" + preco);
		}

	}

}
