package dados;

import java.text.ParseException;
import java.text.SimpleDateFormat;

public class Validacoes {
	public static boolean validaData(String dataString){
		SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");

		try {
			format.parse(dataString);
			return true;
		}
		catch(ParseException e){
			return false;
		}

	}
}
